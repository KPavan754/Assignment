# Webhook Receiver

## Setup

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Start MongoDB locally or use MongoDB Atlas.

3. Run the Flask app:

```bash
python app.py
```

4. Set your GitHub repo webhook to:

```
http://<your-public-url>/webhook
```

Use ngrok if testing locally:

```bash
ngrok http 5000
```

5. Visit `http://localhost:5000` to view the UI.